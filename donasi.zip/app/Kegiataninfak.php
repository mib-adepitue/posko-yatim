<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kegiataninfak extends Model
{
    //
}
