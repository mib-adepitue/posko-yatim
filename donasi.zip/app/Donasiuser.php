<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Donasiuser extends Model
{
    //
}
