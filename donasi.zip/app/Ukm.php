<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ukm extends Model
{
    //
}
