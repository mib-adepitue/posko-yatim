<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
class ManageMitra extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mitra = DB::table('mitras')
                ->join('admins', 'admins.id', '=', 'mitras.created_by')
                ->select('mitras.*', 'admins.name as namaadmin')
                ->get();
            return view('managemitra.index',['mitra' => $mitra]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('managemitra.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (is_numeric($request->jumlah) != TRUE ) {
            return redirect()->back()->withInput()->with('gagal', 'Jumlah Anggota Harus Angka');
        }
        else if($request->jumlah < 1) {
            return redirect()->back()->withInput()->with('gagal', 'Jumlah Anggota Harus Lebih Dari 0');
        }
        $mitra = new \App\Mitra;
        $mitra->nama    = $request->nama;
        $mitra->alamat  = $request->alamat;
        $mitra->email   = $request->email;
        $mitra->jumlah  = $request->jumlah;
        $mitra->created_by = \Auth::user()->id;
        $mitra->save();
        return redirect()->back()->with('status', 'Berhasil Menambahkan Mitra');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $mitra = \App\Mitra::findOrfail($id);   
        return view('managemitra.edit',['mitra' => $mitra ]);    
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if (is_numeric($request->jumlah) != TRUE ) {
            return redirect()->back()->with('gagal', 'Jumlah Anggota Harus Angka');
        }
        else if($request->jumlah < 1) {
            return redirect()->back()->with('gagal', 'Jumlah Anggota Harus Lebih Dari 0');
        }
        $mitra = \App\Mitra::findOrfail($id);
        $mitra->nama    = $request->nama;
        $mitra->email    = $request->email;
        $mitra->alamat    = $request->alamat;
        $mitra->jumlah    = $request->jumlah;
        $mitra->updated_by    = \Auth::user()->name;
        $mitra->save();

        return redirect()->back()->with('status', 'Data Mitra Telah Diedit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $cekbeasiswa = \App\Beasiswa::count('id_mitra', '=' ,'$id');
        if ($cekbeasiswa >= 1)
        return redirect()->back()->with('gagal', 'Data Tidak Dapat Dihapus, ada penerima beasiswa dari mitra ini');
        
        $mitra = \App\Mitra::findOrfail($id);
        $mitra->delete();
        return redirect()->back()->with('status', 'Data Mitra Telah Dihapus');

    }
}
