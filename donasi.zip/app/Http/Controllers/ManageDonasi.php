<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManageDonasi extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function index(Request $request)
    // {
    //     $status = $request->get('status');
    //     if($status){
    //         $books = \App\Penyaluran::where('nama', "LIKE",
    //             "%$keyword%")->where('status', strtoupper($status))->paginate(10);
    //     } else {
    //         $books = \App\Penyaluran::where("nama", "LIKE",
    //             "%$keyword%")->paginate(10);
    //     }
    //     return view('Pemberdayaanadmin.index', ['book' => $books]);
    // }
    
    public function index(Request $request)
    {
        //$donasi = \App\Donasiuser::where('status','belum')->get();
        $status = $request->get('status');
        $users = \App\Donasi::get();
        // dd($users);
            if($status == 'belum') {
                $users = \App\Donasi::where('status', '=', $status)->orderBy('updated_at', 'desc')->get();
            } else if($status == 'sampai') {
                $users = \App\Donasi::with('admins')//->where('donasis.status', $status)
                 ->join('admins', 'admins.id', '=', 'donasis.confirm_by')
                 ->select('donasis.*', 'admins.name as namaadmin')
                 ->orderBy('updated_at', 'desc')
                ->get();
            } 
            // if($users->confirm_by){
            //     $users= DB::table('donasis')
            //     ->join('admins', 'admins.id', '=', 'donasis.confirm_by')
            //     ->select('donasis.*', 'admins.name as namaadmin')
            //     ->where('donasis.status', '=', $status)
            //     ->get();
        //     // }
        // }else 
            //$users = \App\Donasi::get();
        // $u = $users->confirm_by;
       // dd($users);
        // if($users->confirm_by) {
           
        // }
            // dd($users);
           // $users= DB::table('donasis')
           //      ->join('admins', 'admins.id', '=', 'donasis.confirm_by')
           //      ->select('donasis.*', 'admins.name as namaadmin')
           //      ->get();
           //      dd($users);
        
       // dd($users);
        return view('managedonasi.donasiuser', ['donasi' => $users ]);
    }
    // public function index()
    // {
    //     $donasii = \App\Donasi::where('status','belum')->get();

    //     return view('managedonasi.index', ['donasi' => $donasii ]);
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $donasisampai = \App\Donasi::findOrFail($id);
        $donasisampai->status='sampai';
        $donasisampai->confirm_by = \Auth::user()->id;
         $tambah = $donasisampai->jumlah;
        $donasisampai->save();

        $totaldonasi = \App\Totaldonasi::find(1);
        $totall = $totaldonasi->total;
        $totaldonasi->total = $totall + $tambah ;
        
        $totaldonasi->save();
        return redirect()->back()->with('status', 'Donasi Telah Diterima');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
