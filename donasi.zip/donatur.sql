-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 30 Mar 2019 pada 07.36
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `donatur`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `phone`, `foto`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(5, 'Brian', 'Brian@gmail.com', '082344949505', 'fotoadmin/ul9DQDglKndYwKpIRexE9Dy6ytnsrSFKC1oYxar6.png', NULL, '$2y$10$63YSqfpGzTPjTd4Fat5QguK3H45rTj7VB04IiOLabAAvcopZZFXYG', NULL, '2019-03-14 06:17:04', '2019-03-19 09:00:49'),
(11, 'khaeruddinasdar', 'lii@gmail.com', '0875676', 'fotoadmin/HRy6VMxgsqPXdq7xlyeIpU2tMTjr5MFeHfQQJmwH.png', NULL, '$2y$10$N3SrVldFUIc3PvuTAxwgY.Xgetm00fl5md/gav.edLggxqehgv1I2', NULL, '2019-03-21 19:24:28', '2019-03-21 19:24:28'),
(12, 'khaeruddinasdar', 'khaeruddinasdar12@gmail.com', '082344949505', 'fotoadmin/KEBwxUl9cGx34Ir5xx1ZZLR0eC5BOOP64JPggRM0.png', NULL, '$2y$10$mkYIe7l8Xef.O7cUcR3.cOG7X5LF6.lo4.pE/FPXwN3H9LGq4Tv2S', NULL, '2019-03-21 19:29:57', '2019-03-21 19:29:57');

-- --------------------------------------------------------

--
-- Struktur dari tabel `beasiswas`
--

CREATE TABLE `beasiswas` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_penerima` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `dokumentasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_persemester` int(11) NOT NULL,
  `jumlah_total` int(11) DEFAULT NULL,
  `lama` int(11) NOT NULL,
  `pendidikan` enum('S1','D3') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_mitra` int(10) UNSIGNED NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `kampus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `beasiswas`
--

INSERT INTO `beasiswas` (`id`, `nama_penerima`, `deskripsi`, `dokumentasi`, `jumlah_persemester`, `jumlah_total`, `lama`, `pendidikan`, `status`, `id_mitra`, `created_by`, `updated_by`, `created_at`, `updated_at`, `kampus`) VALUES
(4, 'Astridevi', 'asas', 'fotobeasiswa/hvpB7z9TcdZgXa1tjg5uqLyqvSyOG8yO6xEcJryx.png', 100000, 800000, 0, 'S1', 'inactive', 1, 5, NULL, '2019-03-19 11:12:15', '2019-03-19 11:29:39', ''),
(5, 'Mukrisa', 'dia goblok', 'fotobeasiswa/moGkhwm72mjAjIlzkvqWKpGFP2PgM7Hl3kcGlwVy.png', 500000, 2000000, 4, 'S1', 'active', 1, 5, NULL, '2019-03-19 11:41:19', '2019-03-21 23:26:59', ''),
(6, 'sela', 'sadashdgashd', 'fotobeasiswa/SsJekIpeeqk3vBh8GChyPHSBlyo3fElzBDPXdro7.png', 100000, 500000, 3, 'S1', 'active', 1, 5, NULL, '2019-03-19 18:37:25', '2019-03-21 23:23:56', ''),
(7, 'Steve', 'Dia pintar banget', 'fotobeasiswa/hhSBrvcZj3MGjzgqr58wPMQCdEXPBRoYYZVHe06o.png', 300000, 300000, 5, 'D3', 'active', 2, 5, NULL, '2019-03-20 19:21:59', '2019-03-20 19:21:59', ''),
(8, 'Gunawan', 'jggjh', 'fotobeasiswa/kgDQKO5lkWVpgCFolrymeTujyfYXiMnJG7VYbmhw.png', 200000, 200000, 7, 'S1', 'active', 1, 5, NULL, '2019-03-21 06:41:53', '2019-03-21 06:41:53', ''),
(9, 'Lidia', 'Bagus maret mantap', 'fotobeasiswa/IfaPkjC3VQiHJKt5YBYQ3RIoYN7JM9csTbcLA0dE.png', 100000, 100000, 7, 'S1', 'active', 1, 5, NULL, '2019-03-21 23:28:07', '2019-03-21 23:28:07', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `donasis`
--

CREATE TABLE `donasis` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nohp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirm_by` int(10) UNSIGNED DEFAULT NULL,
  `pekerjaan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('sampai','belum') COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `foto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `donasis`
--

INSERT INTO `donasis` (`id`, `nama`, `email`, `nohp`, `confirm_by`, `pekerjaan`, `status`, `jumlah`, `foto`, `created_at`, `updated_at`) VALUES
(3, 'umar', 'unna@gmail.com', '08231231223', 5, 'free', 'sampai', 15000, 'buktiuser/QEUJ3cIrFMCPQMPJ0x92kOpks60Oo9nCF42L0I0c.png', NULL, '2019-03-21 06:24:39'),
(4, 'putri', 'putri@gmail.com', '0987654321', 5, 'ada', 'sampai', 80000, NULL, NULL, '2019-03-17 16:55:22'),
(5, 'ria', 'ria@gmail.com', '082123123123', 5, 'CEO', 'sampai', 200000, NULL, NULL, '2019-03-17 17:11:38'),
(6, 'adhe', 'adhe@gmail.com', '097632543614124', 5, 'siswa', 'sampai', 25000, NULL, NULL, '2019-03-18 02:54:43'),
(7, 'fitra', 'fitra@gmail.com', '08234495959', NULL, 'pengusaha', 'belum', 451, NULL, '2019-03-21 01:16:59', '2019-03-21 01:16:59'),
(8, 'Dirga', 'dirga@gmail.com', '08234495959', NULL, 'polisi', 'belum', 555, NULL, '2019-03-21 01:33:57', '2019-03-21 01:33:57'),
(9, 'Dirga', 'dirga@gmail.com', '08234495959', NULL, 'polisi', 'belum', 555, NULL, '2019-03-21 01:34:25', '2019-03-21 01:34:25'),
(10, 'Dirga', 'dirga@gmail.com', '08234495959', NULL, 'polisi', 'belum', 555, NULL, '2019-03-21 01:34:48', '2019-03-21 01:34:48'),
(11, 'Mulya', 'Mulya@gmail.com', '082345968722', NULL, 'pengusaha miskin', 'belum', 600, NULL, '2019-03-21 01:37:22', '2019-03-21 01:37:22'),
(12, 'khaeruddinasdar', 'asdar@gmail.com', '08234495959', NULL, 'Mahasiswaasasasas', 'belum', 556, NULL, '2019-03-21 06:15:28', '2019-03-21 06:15:28'),
(13, 'khaeruddinasdar', 'asdar@gmail.com', '08234495959', NULL, 'Mahasiswaasasasas', 'belum', 556, NULL, '2019-03-21 06:18:18', '2019-03-21 06:18:18'),
(14, 'khaeruddinasdar', 'asdar@gmail.com', '08234495959', 5, 'Mahasiswaasasasas', 'sampai', 556, 'buktiuser/G9saqb6ri02Ljfb9iHKfkuL8xmfVcx9YxKdDohxR.png', '2019-03-21 06:19:52', '2019-03-22 03:02:11'),
(15, 'ibnu', 'ibnu@gmail.com', '082344595009', 5, 'mahasiswa', 'sampai', 560, 'buktiuser/eFsQ2ZE8rR4ZWaruiFhlaV0ueGImvmNdSbQjv7Xt.png', '2019-03-21 16:07:45', '2019-03-21 16:28:00'),
(16, 'Cahaya', 'cahaya@gmail.com', '0823445060690', NULL, 'mahasiswa', 'belum', 100000, NULL, '2019-03-22 01:50:13', '2019-03-22 01:50:13'),
(17, 'hdhddhhd', 'sjsjsjs@gmail.com', '085255995255', 5, 'ddddddd', 'sampai', 200000, 'buktiuser/hUTlB75TH30e06glxgnvjKN2GcOgg0mkvdWzRzmt.png', '2019-03-22 03:07:00', '2019-03-22 03:09:29'),
(18, 'khaeruddinasdar', 'astridevi@gmail.com', '08234495959', NULL, 'Mahasiswaasasasas', 'belum', 0, NULL, '2019-03-22 03:14:30', '2019-03-22 03:14:30'),
(19, 'khaeruddinasdar', 'khaeruddinasdar12@gmail.com', '08234495959', NULL, 'qw', 'belum', 12, NULL, '2019-03-22 03:15:30', '2019-03-22 03:15:30'),
(20, 'khaeruddinasdar', 'asdar@gmail.com', '08234495959', NULL, 'siswa', 'belum', 100000, NULL, '2019-03-22 03:24:31', '2019-03-22 03:24:31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `donasiusers`
--

CREATE TABLE `donasiusers` (
  `id` int(10) UNSIGNED NOT NULL,
  `jumlah` int(11) NOT NULL,
  `foto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('sampai','belum','proses') COLLATE utf8mb4_unicode_ci NOT NULL,
  `iduser` int(10) UNSIGNED DEFAULT NULL,
  `confirm_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `donasiusers`
--

INSERT INTO `donasiusers` (`id`, `jumlah`, `foto`, `status`, `iduser`, `confirm_by`, `created_at`, `updated_at`) VALUES
(2, 200000, 'buktidonatur/qBkF6Dw0GyJgRLrFU7dsq0gzEgUFNV7QHiyihz2Q.png', 'sampai', 6, 5, NULL, '2019-03-20 06:23:34'),
(3, 200000, 'buktidonatur/J67VRz8z8zV5nSnvdhnKHykEe6VepbXxHyNfizlJ.png', 'sampai', 6, 5, NULL, '2019-03-20 07:09:24'),
(4, 25000, 'buktidonatur/jCuLmbdZylNlOZlCOV736gATqSB54INMmg78R08v.png', 'sampai', 6, 5, NULL, '2019-03-20 07:11:51'),
(5, 450, NULL, 'belum', 6, NULL, '2019-03-20 08:28:22', '2019-03-20 08:28:22'),
(6, 450, NULL, 'belum', 6, NULL, '2019-03-20 08:32:33', '2019-03-20 08:32:33'),
(7, 450, NULL, 'belum', 6, NULL, '2019-03-20 08:34:34', '2019-03-20 08:34:34'),
(8, 450, NULL, 'belum', 6, NULL, '2019-03-20 08:39:53', '2019-03-20 08:39:53'),
(9, 600, NULL, 'belum', 6, NULL, '2019-03-20 08:41:12', '2019-03-20 08:41:12'),
(10, 600, 'buktidonatur/7wcGsb5uWtw0HQaG2dsyjB6X6zFI4jLhmCYOrLFC.png', 'sampai', 6, 5, '2019-03-20 08:41:22', '2019-03-21 16:21:37'),
(11, 450, NULL, 'belum', 6, NULL, '2019-03-20 15:53:14', '2019-03-20 15:53:14'),
(12, 500, NULL, 'belum', 6, NULL, '2019-03-20 15:55:35', '2019-03-20 15:55:35'),
(13, 600, NULL, 'belum', 6, NULL, '2019-03-20 23:11:32', '2019-03-20 23:11:32'),
(14, 890, NULL, 'belum', 6, NULL, '2019-03-20 23:13:12', '2019-03-20 23:13:12'),
(15, 600000, NULL, 'belum', 6, NULL, '2019-03-20 23:25:03', '2019-03-20 23:25:03'),
(16, 700, NULL, 'belum', 6, NULL, '2019-03-21 01:29:15', '2019-03-21 01:29:15'),
(17, 800, 'buktidonatur/rLuE2Vz0XlkWWNXQ39nJHSTyfvfNcBMmhVuxp4HP.png', 'sampai', 6, 5, '2019-03-21 06:49:42', '2019-03-21 06:58:27'),
(18, 789, 'buktidonatur/abd2EZZFECRRg8ZnK3f8VtqF3q2Exh5FCSS0N4iL.png', 'sampai', 6, 5, '2019-03-21 06:51:13', '2019-03-21 06:55:34'),
(19, 250, NULL, 'belum', 6, NULL, '2019-03-21 23:39:53', '2019-03-21 23:39:53'),
(20, 12, NULL, 'belum', 6, NULL, '2019-03-23 20:12:36', '2019-03-23 20:12:36');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kegiataninfaks`
--

CREATE TABLE `kegiataninfaks` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_kegiatan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dokumentasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `kegiataninfaks`
--

INSERT INTO `kegiataninfaks` (`id`, `nama_kegiatan`, `deskripsi`, `jumlah`, `created_by`, `updated_by`, `dokumentasi`, `created_at`, `updated_at`) VALUES
(1, 'Sunat cewe', 'bagus dan bermanfaat', 50000, 5, NULL, 'kegiataninfak/MaFVqOb9QSdcTW70oqvOh0DZkQWyzN067lcHWcs5.png', '2019-03-21 23:31:01', '2019-03-21 23:31:01');

-- --------------------------------------------------------

--
-- Struktur dari tabel `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_03_07_134613_create_admins_table', 2),
(4, '2019_03_07_135215_create_admins_table', 3),
(5, '2019_03_11_061051_create_pemberdayaans_table', 4),
(6, '2019_03_11_073559_create__pemberdayaans_table', 5),
(7, '2019_03_11_074155_create__pemberdayaans_table', 6),
(8, '2019_03_11_155101_create_donasis_table', 7),
(9, '2019_03_11_161916_create_donasis_table', 8),
(10, '2019_03_11_163836_create_totaldonasis_table', 9),
(11, '2019_03_12_012304_create_donasis_table', 10),
(12, '2019_03_13_175846_penyesuaiain_users_table', 11),
(13, '2019_03_13_184201_create_penyalurans_create', 12),
(14, '2019_03_14_171005_penyesuaian_table_user', 13),
(15, '2019_03_15_041150_create_validasibayar_table', 14),
(16, '2019_03_15_162157_create_donasiusers_table', 15),
(17, '2019_03_15_162607_create_donasiusers_table', 16),
(18, '2019_03_16_231853_create_penyalurans_table', 17),
(19, '2019_03_17_001206_create_penyalurans_table', 18),
(20, '2019_03_17_094943_create_donasiusers_table', 19),
(21, '2019_03_17_095837_create_donasis_table', 20),
(22, '2019_03_17_101837_create_penyalurans_table', 21),
(23, '2019_03_17_102255_create_penyalurans_table', 22),
(24, '2019_03_17_110526_create_penyalurans_table', 23),
(25, '2019_03_17_130943_create_donasis_table', 24),
(26, '2019_03_18_074854_create_anakyatims_table', 25),
(27, '2019_03_18_075123_create_anakyatims_table', 26),
(28, '2019_03_18_083918_create_anakyatims_table', 27),
(29, '2019_03_18_124638_create_mitras_table', 28),
(30, '2019_03_18_140110_create_mitras_table', 29),
(31, '2019_03_19_104640_create_ukms_table', 30),
(32, '2019_03_19_110155_create_ukms_table', 31),
(33, '2019_03_19_120246_create_beasiswas_table', 32),
(34, '2019_03_19_142425_create_kegiataninfaks_table', 33),
(35, '2019_03_19_181941_create_beasiswas_table', 34),
(36, '2019_03_19_182223_create_beasiswas_table', 35),
(37, '2019_03_19_183607_create_beasiswas_table', 36),
(38, '2019_03_20_051600_create_ukms_table', 37),
(39, '2019_03_20_052229_create_ukms_table', 38),
(40, '2019_03_20_132453_create_donasiusers_table', 39),
(41, '2019_03_22_070839_create_totaldonasis_table', 40),
(42, '2019_03_25_163722_sesuaikan_table_users', 41),
(43, '2019_03_25_182243_pesesuaikan_table_users', 41),
(44, '2019_03_28_044000_penyesuaian_beasiswa', 41);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mitras`
--

CREATE TABLE `mitras` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah` int(11) NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `mitras`
--

INSERT INTO `mitras` (`id`, `nama`, `alamat`, `email`, `jumlah`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'Pt Liny Komputer', 'makassar jl', 'lini@gmail.com', 12, 5, 'Brian', '2019-03-19 04:46:08', '2019-03-19 08:48:44'),
(2, 'Juliastri CV', 'bone', 'bone@gmail.com', 15, 5, NULL, '2019-03-19 05:52:09', '2019-03-19 05:52:09'),
(3, 'asdaras', 'asdar', 'asdar', 3500, 5, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `totaldonasis`
--

CREATE TABLE `totaldonasis` (
  `id` int(10) UNSIGNED NOT NULL,
  `total` int(11) NOT NULL,
  `total_tersalurkan` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `totaldonasis`
--

INSERT INTO `totaldonasis` (`id`, `total`, `total_tersalurkan`, `created_at`, `updated_at`) VALUES
(1, 350556, 750000, NULL, '2019-03-22 03:09:29');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ukms`
--

CREATE TABLE `ukms` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_penerima` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_usaha` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `jumlah_awal` int(11) NOT NULL,
  `jumlah_total` int(11) DEFAULT NULL,
  `dokumentasi` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `lama` int(11) NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `ukms`
--

INSERT INTO `ukms` (`id`, `nama_penerima`, `nama_usaha`, `deskripsi`, `jumlah_awal`, `jumlah_total`, `dokumentasi`, `status`, `lama`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
(3, 'Astridevi', 'Jual tempe', 'Devi kodong', 100000, 100000, 'fotoukm/dXtcN7uAax7eflrP1IdiZFdunlCXEyzeWEEJnsZV.png', 'active', 1, 5, NULL, '2019-03-21 23:21:18', '2019-03-21 23:21:18');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `totaldonasi` int(11) DEFAULT NULL,
  `nohp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `foto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pekerjaan` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_by` int(10) UNSIGNED DEFAULT NULL,
  `donasi_awal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `totaldonasi`, `nohp`, `foto`, `pekerjaan`, `alamat`, `status`, `deleted_by`, `donasi_awal`) VALUES
(6, 'Astridevi', 'astridevi@gmail.com', NULL, '$2y$10$8HGtk/9jNko1xOjPbHs8Febxzc8FsKx71rJQJsF1yyjgV6PaY7KVS', 'NDg6DBSCnFZONA13nfp8HYgARHoitP7XQEyQYsS4PgGJpV1snkoxIuFPTshj', '2019-03-19 22:28:32', '2019-03-23 20:03:43', 347189, '082344949505', 'fotouser/aldxbDlOlm5xk9EnqyxEdwdWsUqxj8HoaGwjxWoM.png', 'Mahasiswa', 'makassar', 'active', NULL, 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indeks untuk tabel `beasiswas`
--
ALTER TABLE `beasiswas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `beasiswas_created_by_foreign` (`created_by`),
  ADD KEY `beasiswas_id_mitra_foreign` (`id_mitra`);

--
-- Indeks untuk tabel `donasis`
--
ALTER TABLE `donasis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `donasis_confirm_by_foreign` (`confirm_by`);

--
-- Indeks untuk tabel `donasiusers`
--
ALTER TABLE `donasiusers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `donasiusers_iduser_foreign` (`iduser`),
  ADD KEY `donasiusers_confirm_by_foreign` (`confirm_by`);

--
-- Indeks untuk tabel `kegiataninfaks`
--
ALTER TABLE `kegiataninfaks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kegiataninfaks_created_by_foreign` (`created_by`);

--
-- Indeks untuk tabel `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `mitras`
--
ALTER TABLE `mitras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mitras_created_by_foreign` (`created_by`);

--
-- Indeks untuk tabel `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indeks untuk tabel `totaldonasis`
--
ALTER TABLE `totaldonasis`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ukms`
--
ALTER TABLE `ukms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ukms_created_by_foreign` (`created_by`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_deleted_by_foreign` (`deleted_by`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `beasiswas`
--
ALTER TABLE `beasiswas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `donasis`
--
ALTER TABLE `donasis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `donasiusers`
--
ALTER TABLE `donasiusers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `kegiataninfaks`
--
ALTER TABLE `kegiataninfaks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT untuk tabel `mitras`
--
ALTER TABLE `mitras`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `totaldonasis`
--
ALTER TABLE `totaldonasis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `ukms`
--
ALTER TABLE `ukms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `beasiswas`
--
ALTER TABLE `beasiswas`
  ADD CONSTRAINT `beasiswas_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `beasiswas_id_mitra_foreign` FOREIGN KEY (`id_mitra`) REFERENCES `mitras` (`id`);

--
-- Ketidakleluasaan untuk tabel `donasis`
--
ALTER TABLE `donasis`
  ADD CONSTRAINT `donasis_confirm_by_foreign` FOREIGN KEY (`confirm_by`) REFERENCES `admins` (`id`);

--
-- Ketidakleluasaan untuk tabel `donasiusers`
--
ALTER TABLE `donasiusers`
  ADD CONSTRAINT `donasiusers_confirm_by_foreign` FOREIGN KEY (`confirm_by`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `donasiusers_iduser_foreign` FOREIGN KEY (`iduser`) REFERENCES `users` (`id`);

--
-- Ketidakleluasaan untuk tabel `kegiataninfaks`
--
ALTER TABLE `kegiataninfaks`
  ADD CONSTRAINT `kegiataninfaks_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `admins` (`id`);

--
-- Ketidakleluasaan untuk tabel `mitras`
--
ALTER TABLE `mitras`
  ADD CONSTRAINT `mitras_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `admins` (`id`);

--
-- Ketidakleluasaan untuk tabel `ukms`
--
ALTER TABLE `ukms`
  ADD CONSTRAINT `ukms_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `admins` (`id`);

--
-- Ketidakleluasaan untuk tabel `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_deleted_by_foreign` FOREIGN KEY (`deleted_by`) REFERENCES `admins` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
