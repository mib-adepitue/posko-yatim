<?php $__env->startSection('title'); ?> Detail Penyaluran <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Nama Penerima</b></label><br>
			<?php echo e($show->name); ?>

			<br><br>
			<label><b>Jumlah</b></label><br>
			Rp. <?php echo e(format_uang($show->jumlah)); ?>

			<br><br>
			<label><b>Deskripsi </b></label><br>
			<?php echo e($show->deskripsi); ?>

			<br><br>
			<label><b>Penulis </b></label><br>
			<?php echo e($show->namaadmin); ?>

			<br><br>
			<label><b>Dokumentasi </b></label><br>
			<?php if($show->dokumentasi): ?>
			<img src="<?php echo e(asset('storage/' . $show->dokumentasi)); ?>"
			width="120px">
			<?php endif; ?>

		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>