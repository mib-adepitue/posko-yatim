<?php $__env->startSection('title'); ?>Tambah Ukm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<div class="box-body">

<h2 align="center">Tambah UKM</h2>
<h4 align="center">Saldo Rp.<?php echo e($total); ?></h4>
		<form
		action="<?php echo e(route('ukm.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama penerima ukm</label> <br>
		<input type="text" class="form-control" name="nama_penerima"
		placeholder="Masukkan nama penerima" value="<?php echo e(old('nama_penerima')); ?>" required>
		<br>
		<label for="title">Nama usaha</label> <br>
		<input type="text" class="form-control" name="nama_usaha"
		placeholder="Masukkan nama usaha" value="<?php echo e(old('nama_usaha')); ?>" required>
		<br>
		<label for="cover">Dokumentasi</label>
		<input type="file" class="form-control" name="dokumentasi" value="<?php echo e(old('dokumentasi')); ?>" required>
		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Deskripsi kegiatan ini" rows="5" required><?php echo e(old('deskripsi')); ?></textarea>
		<br>
		<label for="title">Lama donasi (tahun)</label> <br>
		<input type="text" class="form-control" name="lama" onkeypress="return isNumberKey(event)" placeholder="Lama donasi (bilangan tahun)" value="<?php echo e(old('lama')); ?>" required>
		<br>
	<label for="stock">Jumlah  </label><br>
	<input type="number" class="form-control" id="stock" name="jumlah_awal"
	min=0 value="<?php echo e(old('jumlah')); ?>" placeholder="Banyak dana " required>
	<br>
	<input type="submit" name=""
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>