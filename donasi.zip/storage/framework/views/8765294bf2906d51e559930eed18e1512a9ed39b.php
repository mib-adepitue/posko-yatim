<?php $__env->startSection('title'); ?>Create Admin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<h2 align="center">Add Admin</h2>
			<div class="box-body">
		<form
		action="<?php echo e(route('manageadmin.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="nama">Name </label> <br>
		<input type="text" class="form-control" name="nama"
		placeholder="Your name" value="<?php echo e(old('nama')); ?>" required>
		<br>
		<label for="emai">Email </label> <br>
		<input type="email" class="form-control" name="email"
		placeholder="Your email" value="<?php echo e(old('email')); ?>" required>
		<br>
		<label for="phone">Phone </label> <br>
		<input type="text" class="form-control" name="phone"
		placeholder="Your phone number" value="<?php echo e(old('phone')); ?>" required>
		<br>
		<label for="password">Password </label> <br>
		<input type="password" class="form-control" name="password" id="pw1" 
		placeholder="Your password min 6" value="<?php echo e(old('pass')); ?>" pattern="^\S{6,}$" 
		onchange="this.setCustomValidity(this.validity.patternMismatch ? 'minimal 6 karakter' : '');"  required>
		<span id="notif" ></span>
		<br>
		<label for="password-confirm">Confirm Password </label> <br>
		<input type="password" class="form-control" name="confpass" id="pw2" 
		placeholder="Your password" value="<?php echo e(old('confpass')); ?>" required>
		<br>
		<label for="fotoadmin">Photo</label>
		<input type="file" class="form-control" name="fotoadmin" value="<?php echo e(old('fotoadmin')); ?>" accept="image/*" required>
		<br>
		<input type="submit" name="addadmin" class="btn btn-primary btn-flat" value="Add admin">
	
</form>
</div>
</div>
</div>
</div>
</div>
<script type="text/javascript">
            window.onload = function () {
                document.getElementById("pw1").onchange = validatePassword;
                document.getElementById("pw2").onchange = validatePassword;
            }
            function validatePassword(){
                var pass2=document.getElementById("pw2").value;
                var pass1=document.getElementById("pw1").value;
                if(pass1!=pass2)
                    document.getElementById("pw2").setCustomValidity("Passwords Tidak Sama, Coba Lagi");
                else
                    document.getElementById("pw2").setCustomValidity('');
            }
        </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>