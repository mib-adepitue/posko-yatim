<?php $__env->startSection('title'); ?> Detail kegiatan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Nama Kegiatan</b></label><br>
			<?php echo e($show->nama_kegiatan); ?>

			<br><br>
			<label><b>Dana yang terpakai</b></label><br>
			Rp. <?php echo e(format_uang($show->jumlah)); ?>

			<br><br>
			<label><b>Deskripsi </b></label><br>
			<?php echo e($show->deskripsi); ?>

			<br><br>
			<label><b>Dokumentasi </b></label><br>
			<?php if($show->dokumentasi): ?>
			<img src="<?php echo e(asset('storage/' . $show->dokumentasi)); ?>"
			width="185px">
			<?php endif; ?>
			<br><br>
			<label><b>Penulis </b></label><br>
			admin <strong><?php echo e($show->namaadmin); ?></strong>
			<br><br>
			<label><b>Ditulis Pada : </b></label><br>
			<?php echo e($show->created_at); ?>

			<br><br>

		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>