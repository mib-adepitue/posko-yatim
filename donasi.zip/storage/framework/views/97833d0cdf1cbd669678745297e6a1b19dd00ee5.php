<?php $__env->startSection('title'); ?> List Pemberdayaan <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php endif; ?>

			<?php if(Request::get('penyaluran') == NULL): ?>
			<h2>Semua Penyaluran</h2>
			<?php elseif(Request::get('penyaluran') == 'umum'): ?>
			<h2>Penyaluran Umum</h2>
			<?php elseif(Request::get('penyaluran') == 'beasiswa'): ?>
			<h2>Penyaluran Beasiswa</h2>
			<?php elseif(Request::get('penyaluran') == 'ukm'): ?>
			<h2>UKM</h2>
			<?php endif; ?>

			<div class="col-md-6">
				<ul class="nav nav-pills">
					<li class="nav-item">
						<a class="btn-info <?php echo e(Request::get('penyaluran') == NULL &&
						Request::path() == 'admin/penyaluran' ? 'active' : ''); ?>" href="
						<?php echo e(route('penyaluran.index')); ?>">All Post</a>
					<li class="nav-item">
						<a class="btn-info <?php echo e(Request::get('penyaluran') == 'umum' ?
						'active' : ''); ?>" href="<?php echo e(route('penyaluran.index', ['penyaluran' =>
						'umum'])); ?>">Umum</a>
					</li>
					<li class="nav-item">
						<a class="btn-info <?php echo e(Request::get('penyaluran') == 'beasiswa' ?
						'active' : ''); ?>" href="<?php echo e(route('penyaluran.index', ['penyaluran' =>
						'beasiswa'])); ?>">Beasiswa</a>
					</li>
					<li class="nav-item">
						<a class="btn-info <?php echo e(Request::get('penyaluran') == 'ukm' ?
						'active' : ''); ?>" href="<?php echo e(route('penyaluran.index', ['penyaluran' =>
						'ukm'])); ?>">Ukm</a>
					</li>
					</ul>
				</div>

				<div class="row">
					<div class="col-md-12 text-right">
						<a
						href="<?php echo e(route('penyaluran.create')); ?>"
						class="btn btn-info fa fa-plus btn-flat"
						> Mulai Donasi</a>
					</div>
				</div>
				<?php
				$no = 1;
				?>
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table class="table table-bordered table-stripped" id="example1" style="width: 100%">
							<thead>
								<tr>
									<th>No.</th>
									<th>Nama Penerima</th>
									<th>Author</th>
									<th>Diedit oleh</th>
									<th>Jumlah</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $books): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($no++); ?></td>
									<td><?php echo e($books->name); ?></td>
									<td><?php echo e($books->namaadmin); ?></td>
									<td><?php if($books->updated_by): ?><?php echo e($books->updated_by); ?>

									<?php else: ?> Belum diupdate <?php endif; ?></td>
									<td>Rp. <?php echo e(format_uang($books->jumlah)); ?></td>
									<td>
										<div class="row1">
											<a href="<?php echo e(route('penyaluran.edit', ['id' => $books->id])); ?>" class="fa fa-edit"> Edit </a>
											<a href="<?php echo e(route('penyaluran.show', ['id' => $books->id])); ?>" class="fa fa-eye"> View </a>

											<form
											method="POST"
											action="<?php echo e(route('penyaluran.deletepermanent', ['id' => $books->id])); ?>"
											class="d-inline"
											onsubmit="return confirm('Hapus Penyaluran ?')"
											>
											<?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="DELETE">
											<input type="submit" value="Delete" class="btn btn-danger">
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>