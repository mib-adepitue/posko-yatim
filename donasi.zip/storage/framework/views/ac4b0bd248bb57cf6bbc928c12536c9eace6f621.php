
<?php $__env->startSection('title'); ?>Posko yatim - edit profile <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section>
        <div class="dashboard">
            <div class="container">
                <div class="col-md-3 col-md-offset-1">
                    <a href="#" class="thumbnail">
                        <img src="<?php echo e(asset('storage/'. Auth::user()->foto)); ?>" alt="background-user">
                    </a>
                    <div class="list-group">
                        <a href="<?php echo e(route('donatur.dashboard')); ?>" class="list-group-item">Overview</a>
                        <a href="<?php echo e(route('donasi.donatur')); ?>" class="list-group-item">Donasi Sekarang</a>
                        <a href="<?php echo e(route('edit.profile')); ?>" class="list-group-item active">Edit Profil</a>
                        <a href="<?php echo e(route('daftar.donatur')); ?>" class="list-group-item">Lihat daftar donatur</a>
                        <a href="<?php echo e(route('daftar.mitra')); ?>" class="list-group-item">Lihat daftar mitra Posko Yatim</a>
                        <a href="<?php echo e(route('logout')); ?>" class="list-group-item" 
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                        <a data-toggle="modal" data-target="#confirm-absen" class="list-group-item" style="cursor:pointer;">Berhenti jadi donatur</a>
                    </div>
                </div>
                <div class="col-md-6 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert"><?php echo e(session('status')); ?></div>
                     <?php elseif(session('gagal')): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e(session('gagal')); ?></div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> Foto minimal 2MB<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                            <h3 class="text-center">Halo <?php echo e(Auth::user()->name); ?></h3>
                            <p class="text-center text">Update profil anda</p>
                            <form action="<?php echo e(route('proses.edit.profile')); ?>" method="POST" enctype="multipart/form-data" accept="image/*">
                                <?php echo csrf_field(); ?>
                                <div class="input-group">
                                        <div class="input-group-addon"><span class="ti ti-user"></span></div>
                                        <input type="text" class="form-control" id="exampleInputAmount" value="<?php echo e(Auth::user()->name); ?>" name="name" required>
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span>@</span></div>
                                        <input type="email" class="form-control" id="exampleInputAmount" value="<?php echo e(Auth::user()->email); ?>" name="email" required>
                                    </div>
                                    <div class="input-group">
                                    <div class="input-group-addon"><span class="ti ti-money"></div>
                                    <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="Jumlah minimal donasi perbulan" name="donasi" onkeypress="return isNumberKey(event)" value="<?php echo e(Auth::user()->donasi_awal); ?>" required>
                                </div>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti ti-lock"></span></div>
                                        <input placeholder="Masukkan Password Baru      *sensitive" type="password" name="pass" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Minimal 6 Karakter' : ''); if(this.checkValidity()) form.pass2.pattern = this.value;" class="form-control" id="passwordfield" >
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti ti-mobile"></span></div>
                                        <input type="tel" class="form-control" id="exampleInputEmail1" value="<?php echo e(Auth::user()->nohp); ?>" name="nohp" onkeypress="return isNumberKey(event)" required>
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti-id-badge"></span></div>
                                        <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(Auth::user()->pekerjaan); ?>" name="pekerjaan" required>
                                    </div>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti-map-alt"></span></div>
                                        <input type="text" class="form-control" id="exampleInputEmail1" value="<?php echo e(Auth::user()->alamat); ?>" name="alamat" required>
                                    </div>
                                    <div class="input-group">
                                        <label for="exampleInputFile">Upload Foto</label>
                                        <input type="file" id="exampleInputFile" name="profile" >
                                        <p class="help-block">Maximum 2MB.</p>
                                    </div>
                                    <input type="hidden" name="_method" value="PUT">
                                <input type="submit" class="btn btn-default edit" value="Simpan Pembaruan">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="confirm-absen" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Berhenti jadi Donatur</h4>
                            </div>
                            <div class="modal-body">
                                <p>Apakah Anda yakin ingin melanjutkan ?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal" style="margin-top:24px; 
                                background-color: #fb0000; border-color: #fb0000;">Batal</button>
                                <form action="<?php echo e(route('stop-donatur')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                <input type="submit" name="" class="btn btn-primary btn-ok" value="Konfirmasi">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.donatur', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>