<?php $__env->startSection('title'); ?>Edit Pemberdayaan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<div class="box-body">
		<form
		action="<?php echo e(route('penyaluran.update', ['id' => $pemberdayaanadmin->id])); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
	<input
	type="hidden"
	value="PUT"
	name="_method">
		<label for="title">Nama Penerima</label> <br>
		<input type="text" class="form-control" name="nama"
		placeholder="Book title" value="<?php echo e($pemberdayaanadmin->name); ?>" required>
		<br>

		<label for="cover">Dokumentasi</label><br>
		<small class="text-muted">Current cover</small><br>
		<?php if($pemberdayaanadmin->dokumentasi): ?>
		<img src="<?php echo e(asset('storage/' . $pemberdayaanadmin->dokumentasi)); ?>" width="96px"/>
		<?php endif; ?>
		<br><br>
		<input
		type="file"class="form-control"
		name="dokumentasi"
		>
		<small class="text-muted">Kosongkan jika tidak ingin mengubah
		cover</small>
		<br>

		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Give a description about this book"  required><?php echo e($pemberdayaanadmin->deskripsi); ?></textarea>
		<br>
	<label for="stock">Jumlah</label><br>
	<input type="text" class="form-control" id="stock" name="jumlah"
	 value="<?php echo e($pemberdayaanadmin->jumlah); ?>" required>
	<br>
	<label for="title">Jenis Penyaluran</label> <br>
		<select class="form-control" name="penyaluran">
			<option value="umum" <?php echo e($pemberdayaanadmin == "umum" ? 'selected' : ''); ?>>Umum</option>
			<option value="beasiswa" <?php echo e($pemberdayaanadmin == "beasiswa" ? 'selected' : ''); ?>>Beasiswa</option>
			<option value="ukm" <?php echo e($pemberdayaanadmin == "ukm" ? 'selected' : ''); ?>>ukm</option>
		</select>
		<br>
	<input type="submit" class="btn btn-primary" value="PUBLISH">
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>