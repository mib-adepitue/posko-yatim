
<?php $__env->startSection('title'); ?> Detail donatur <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8">

<div class="box">
	<h2 align="center">Detail donatur</h2>
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Photo </b></label><br>
			<img src="<?php echo e(asset('storage/' . $user->foto)); ?>"
			width="160px"><br>
			<label><b>Name </b></label><br>
			<?php echo e($user->name); ?>

			<br><br>
			<label><b>Email</b></label><br>
			<?php echo e($user->email); ?>

			<br><br>
			<label><b>Donasi wajib</b></label><br>
			Rp. <?php echo e(format_uang($user->donasi_awal)); ?>

			<br><br>
			<label><b>Phone </b></label><br>
			<?php echo e($user->nohp); ?>

			<br><br>
			<label><b>Job </b></label><br>
			<?php echo e($user->pekerjaan); ?>

			<br><br>
			<label><b>Address </b></label><br>
			<?php echo e($user->alamat); ?>

			<br><br>
			<label><b>Status </b></label><br>
			<?php if($user->status == 'active'): ?>
								<span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Donatur aktif </i></span>
							<?php else: ?>
							<span class="label label-danger" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Tidak aktif </i></span>
						<?php endif; ?>
		</div>
	</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>