<?php $__env->startSection('title'); ?> List Users <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php elseif(session('gagal')): ?>
			<div class="alert alert-danger">
				<?php echo e(session('gagal')); ?>

			</div>
			<?php endif; ?>
		</div>

			<h2>List users</h2>
		<?php
		$no = 1;
		?>
		<div class="box">
			<!-- /.box-header -->
			<div class="box-body">
				<table class="table table-stripped table-bordered" id="example1" style="width: 100%">
					<thead>
						<tr>
							<th><b>No.</b></th>
							<th><b>Nama</b></th>
							<th><b>Status</b></th>
							<th><b>Email</b></th>
							<th><b>Action</b></th>

						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($users->name); ?></td>
							<td><?php if($users->status == 'active'): ?>
								<span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Donatur aktif </i></span>
							<?php else: ?>
							<span class="label label-danger" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Tidak aktif </i></span>
						<?php endif; ?></td>
						<td><a href="mailto:<?php echo e($users->email); ?>"><?php echo e($users->email); ?></a></td>
							<td>
							<a href="<?php echo e(route('manageuser.show',['id'=>$users->id])); ?>" class="fa fa-eye" >view </a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr></tr>
			</tfoot>
		</table>
	</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>