<?php $__env->startSection('title'); ?> Donasi donatur <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

	<section class="content-header" >
<div class="col-md-12">
	<?php if(session('status')): ?>
	<div class="alert alert-success">
		<?php echo e(session('status')); ?>

	</div>
	<?php endif; ?>
	<?php
	$no = 1;
	?>
	<h2>Donasi donatur</h2>
	<div class="col-md-6">
		<ul class="nav nav-pills">
			<li class="nav-item">
				<a class="btn-success <?php echo e(Request::get('status') == NULL &&
				Request::path() == 'admin/manage-donasi-donatur' ? 'active' : ''); ?>" href="
				<?php echo e(route('manage-donasi-donatur.index')); ?>">All Post</a>
			</li>
			<li class="nav-item">
				<a class="btn-success <?php echo e(Request::get('status') == 'sampai' ?
				'active' : ''); ?>" href="<?php echo e(route('manage-donasi-donatur.index', ['status' =>
				'sampai'])); ?>">Terkirim</a>
			</li>
			<li class="nav-item">
				<a class="btn-success <?php echo e(Request::get('status') == 'belum' ?
				'active' : ''); ?>" href="<?php echo e(route('manage-donasi-donatur.index', ['status' =>
				'belum'])); ?>">Belum Sampai</a>
			</li>
		</ul>
	</div>

		
	<?php if(Request::get('status') == NULL && Request::path() == 'admin/manage-donasi-donatur'): ?>
	<div class="box" style="margin-top: 60px;">
		<div class="box-body">	
			<table id="example1" class="table table-bordered table-striped" style="width: 100%">
				<thead>
					<tr>
						<th>No.</th>
						<th>Nama Pengirim</th>
						<th>Email</th>
						<th>Jumlah Donasi</th>
						<th>Bukti Pembayaran</th>
						<th>Status</th>
						<th>Created at</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($no++); ?></td>
						<td><?php echo e($donasis->name); ?></td>
						<td><?php echo e($donasis->email); ?></td>
						<td>Rp. <?php echo e(format_uang($donasis->jumlah)); ?></td>
						<td><?php if($donasis->foto): ?><img src="<?php echo e(asset('storage/' . $donasis->foto)); ?>"
							width="120px">
						<?php else: ?> Belum dikirim <?php endif; ?></td>
							<td><?php if($donasis->status == 'sampai'): ?>
								<span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Terkirim</i></span>
								<?php else: ?>
								<span class="label label-warning" style="font-size: 13px;"><i class="fa fa-spinner"> Process</i>   </span>
							<?php endif; ?></td>
						<td><?php echo e($donasis->created_at); ?></td>
					</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
					<tfoot>
						<tr>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
		<?php elseif(Request::get('status') == 'sampai'): ?>

		<div class="box" style="margin-top: 60px;">
			<div class="box-body">	
				<table id="example1" class="table table-bordered table-striped" style="width: 100%">
					<thead>
						<tr>
							<th>No.</th>
							<th>Nama Pengirim</th>
							<th>Email</th>
							<th>Jumlah Donasi</th>
							<th>Bukti Pembayaran</th>
							<th>Konfirmasi oleh</th>
							<th>Status</th>
						</tr>
					</thead>

					<tbody>

						<?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($donasis->name); ?></td>
							<td><?php echo e($donasis->email); ?></td>
							<td>Rp. <?php echo e(format_uang($donasis->jumlah)); ?></td>
							<td><img src="<?php echo e(asset('storage/' . $donasis->foto)); ?>"
								width="120px"></td>
							<td>admin <strong><?php echo e($donasis->namaadmin); ?></strong></td>
							<td><span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Diterima</i></span></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</tbody>
						<tfoot>
							<tr>
							</tr>
						</tfoot>
					</table>
				</div>
			</div>
			<?php elseif(Request::get('status') == 'belum'): ?>
			<div class="box" style="margin-top: 60px;">
				<div class="box-body">	
					<table id="example1" class="table table-bordered table-striped" style="width: 100%">
						<thead>
							<tr>
								<th>No.</th>
								<th>Nama Pengirim</th>
								<th>Email</th>
								<th>Jumlah Donasi</th>
								<th>Bukti Pembayaran</th>
								<th>Action</th>
							</tr>
						</thead>

						<tbody>

							<?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($no++); ?></td>
								<td><?php echo e($donasis->name); ?></td>
								<td><?php echo e($donasis->email); ?></td>
								<td>Rp. <?php echo e(format_uang($donasis->jumlah)); ?></td>
								<td><?php if($donasis->foto): ?><img src="<?php echo e(asset('storage/' . $donasis->foto)); ?>"
									width="120px">
									<?php else: ?> <span class="label label-warning" style="font-size: 13px;"><i class="fa fa-spinner"> Process</i> 
									<?php endif; ?></td>
								
								<td><?php if($donasis->foto): ?><form 
				action="<?php echo e(route('manage-donasi-donatur.update', ['id' => $donasis->id])); ?>"
										method="POST">
										<?php echo csrf_field(); ?>
										<input
										type="hidden"
										value="PUT"
										name="_method">
										
										<input onclick="return confirm('Donasi <?php echo e($donasis->name); ?> Telah Diterima ?')" 
										type="submit"
										value="Konfirmasi Bukti"
										class="btn btn-success btn-flat">
										
									</form>
								<?php else: ?>
							<form 
				action="<?php echo e(route('manage-donasi-donatur.update', ['id' => $donasis->id])); ?>"
										method="POST">
										<?php echo csrf_field(); ?>
										<input
										type="hidden"
										value="PUT"
										name="_method">
										
										<input onclick="return confirm('Donasi <?php echo e($donasis->name); ?> Telah Diterima ?')" 
										type="submit"
										value="Konfirmasi Bukti"
										class="btn btn-success btn-flat" disabled="">
										
									</form>
								<?php endif; ?></td>
									
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							</tbody>
							<tfoot>
								<tr>
								</tr>
							</tfoot>
						</table>
					</div>
				</div>
				<?php endif; ?>
			</section>
			</div>
		</div>
		

		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>