
<?php $__env->startSection('title'); ?> List kegiatan infak <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php endif; ?>
			<h2>List kegiatan infak</h2>

				<div class="row">
					<div class="col-md-12 text-right">
						<a
						href="<?php echo e(route('manage-infak.create')); ?>"
						class="btn btn-primary fa fa-plus btn-flat"
						> Tambah kegiatan</a>
					</div>
				</div>
				<?php
				$no = 1;
				?>
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table class="table table-bordered table-stripped" id="example1" style="width: 100%">
							<thead>
								<tr>
									<th>No.</th>
									<th>Nama kegiatan</th>
									<th>jumlah dana</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $infak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infaks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($no++); ?></td>
									<td><?php echo e($infaks->nama_kegiatan); ?></td>
									<td>Rp. <?php echo e(format_uang($infaks->jumlah)); ?></td>
									<td>
										<div class="row1">
											<a href="<?php echo e(route('manage-infak.edit', ['id' => $infaks->id])); ?>" class="fa fa-edit"> Edit </a>
											<a href="<?php echo e(route('manage-infak.show', ['id' => $infaks->id])); ?>" class="fa fa-eye"> View </a>
											<form
											method="POST"
											action="<?php echo e(route('manage-infak.destroy', ['id' => $infaks->id])); ?>"
											class="d-inline"
											onsubmit="return confirm('Hapus Kegiatan Infak ?');"
											>
											<?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="DELETE">
											<input type="submit" value="Delete" class="btn btn-danger">
										</form>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>