<?php $__env->startSection('title'); ?>Edit Pemberdayaan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> Foto minimal 2MB<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
		<div class="box">
			<div class="box-body">
		<form
		action="<?php echo e(route('manageadmin.update', ['id' => $admin->id])); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
	<input
	type="hidden"
	value="PUT"
	name="_method">
		<label for="title">Nama</label> <br>
		<input type="text" class="form-control" name="name"
		 value="<?php echo e($admin->name); ?>" required>
		<br>
		<label for="title">Email</label> <br>
		<input type="text" class="form-control" name="email"
		  value="<?php echo e($admin->email); ?>" required>
		<br>

		<label for="cover">Foto Profile</label><br>
		<small class="text-muted">Current cover</small><br>
		<?php if($admin->foto): ?>
		<img src="<?php echo e(asset('storage/' . $admin->foto)); ?>" width="120px"/>
		<?php endif; ?>
		<br><br>
		<input
		type="file"class="form-control"
		name="foto" accept="image/*"
		>
		<small class="text-muted">Kosongkan jika tidak ingin mengubah
		cover</small>
		<br>
		<br>
		
	<label for="stock">Kontak</label><br>
	<input type="number" class="form-control" id="stock" name="nohp"
	min=0 value="<?php echo e($admin->phone); ?>" required>
	<br>
	<label for="stock">Ubah Password</label><br>
	<input type="password" placeholder="minimal 6 karakter" class="form-control" id="stock" name="password" pattern="^\S{6,}$" 
		onchange="this.setCustomValidity(this.validity.patternMismatch ? 'minimal 6 karakter' : '');">
	<br>
	<input type="submit" class="btn btn-primary" value="PUBLISH">
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>