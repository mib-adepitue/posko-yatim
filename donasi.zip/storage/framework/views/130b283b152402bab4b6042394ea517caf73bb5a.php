
<?php $__env->startSection('title'); ?> List Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php elseif(session('gagal')): ?>
			<div class="alert alert-danger">
				<?php echo e(session('gagal')); ?>

			</div>
			<?php endif; ?>
			<h2>List Admin</h2>
		</div>
		<div class="row mb-3">
			<div class="col-md-12 text-right">
				<a
				href="<?php echo e(route('manageadmin.create')); ?>"
				class="btn fa fa-plus btn-primary btn-flat"
				> Create Admin</a>
			</div>
		</div>

		<?php
		$no = 1;
		?>
		<div class="box">
			<!-- /.box-header -->
			<div class="box-body">
				<table class="table table-stripped table-bordered" id="example1" style="width: 100%">
					<thead>
						<tr>
							<th><b>No.</b></th>
							<th><b>Nama</b></th>
							<th><b>Action</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admins): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($admins->name); ?></td>
							<td>
							<a href="<?php echo e(route('manageadmin.show',['id'=>$admins->id])); ?>" class="fa fa-eye" >view </a>
							<a href="<?php echo e(route('manageadmin.edit',['id'=>$admins->id])); ?>" class="fa fa-edit">edit </a>
							
							<form
							method="POST"
							action="<?php echo e(route('manageadmin.destroy', ['id'=> $admins->id])); ?>"
							class="d-inline"
							onsubmit="return confirm('Delete this Account permanently?')"
							>
							<?php echo csrf_field(); ?>
							<input type="hidden" name="_method" value="DELETE">
							<input type="submit" value="Delete" class="btn btn-danger btn-flat">
						</form>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
			</tfoot>
		</table>
	</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>