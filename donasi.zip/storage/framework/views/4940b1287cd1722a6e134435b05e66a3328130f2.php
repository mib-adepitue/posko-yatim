<?php $__env->startSection('content'); ?>
    <section>
        <div class="input">
            <div class="container main-header">
                <h2 class="text-center">Daftar penerima beasiswa</h2>
                <h4 class="text-center">Akan di salurkan kepada mereka yang membutuhkan</h4>
                <div class="col-md-6 col-md-offset-3">
                      <form action="<?php echo e(route('view-kegiatan-infak.index')); ?>" >
                            <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="cari" value="<?php echo e(Request::get('cari')); ?>" placeholder="Cari nama penerima...">
                        <span class="input-group-btn">
                            <input class="btn btn-default" type="submit" value="Go">
                        </span>
                        </form>
                    </div>
                </div>
            </div>
            </div>
            <div class="container main-header">
                <hr style="background-color:#e2dede; height:1px;">
                <div>
                    <?php $__currentLoopData = $infak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infaks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(route('view-kegiatan-infak.show', ['id' => $infaks->id])); ?>" class="thumbnail thumb">
                            <img src="<?php echo e(asset('storage/'. $infaks->dokumentasi)); ?>" alt="...">
                            <div class="caption">
                                <h3><?php echo e($infaks->nama_kegiatan); ?></h3>
                                <p>Dana <strong>Rp. <?php echo e(format_uang($infaks->jumlah)); ?></strong></p>
                            </div>
                        </a>
                    </div>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="container">
                <?php echo e($infak->links()); ?>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.viewpublic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>