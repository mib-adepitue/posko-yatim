<?php $__env->startSection('title'); ?> List Ukm <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
			<h2>List Ukm__ Saldo Rp. <?php echo e($total); ?></h2>

				<div class="row">
					<div class="col-md-12 text-right">
						<a
						href="<?php echo e(route('ukm.create')); ?>"
						class="btn btn-primary fa fa-plus btn-flat"
						> Tambah UKM</a>
					</div>
				</div>
				<?php
				$no = 1;
				?>
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table class="table table-bordered table-stripped" id="example1" style="width: 100%">
							<thead>
								<tr>
									<th>No.</th>
									<th>Nama penerima</th>
									<th>Nama usaha</th>
									<th>jumlah awal</th>
									<th>jumlah terima</th>
									<th>Lama donasi</th>
									<th>Tambah donasi</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($no++); ?></td>
									<td><?php echo e($ukms->nama_penerima); ?></td>
									<td><?php echo e($ukms->nama_usaha); ?></td>
									<td>Rp. <?php echo e(format_uang($ukms->jumlah_awal)); ?></td>
									<td>Rp. <?php echo e(format_uang($ukms->jumlah_total)); ?></td>
									<!--<td><?php if($ukms->status == 'active'): ?> <span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Active</i></span>-->
									<!-- <?php else: ?><span class="label label-warnign" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Inactive</i></span> -->
									<!--  <?php endif; ?> </td>-->
									<td><?php echo e($ukms->lama); ?> tahun</td>
									<td><button class="btn btn-warning" data-toggle='modal' data-target='#tambahdonasi' style="cursor: pointer;">Tambah Donasi</button></td>
									<td>
										<div class="row1">
											<a href="<?php echo e(route('ukm.edit',['id' => $ukms->id])); ?>" class="fa fa-edit"> Edit </a>
											<a href="<?php echo e(route('ukm.show',['id' => $ukms->id])); ?>" class="fa fa-eye"> View </a>
											<form
											method="POST"
											action="<?php echo e(route('ukm.destroy',['id' => $ukms->id])); ?>"
											class="d-inline"
											onsubmit="return confirm('Hapus ukm 	?')"
											>
											<?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="DELETE">
											<input type="submit" value="Delete" class="btn btn-danger">
										</form>
										</div>
									</td>
								</tr>
								<div class="modal fade" id="tambahdonasi" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Tambah Donasi !</h4>
                        </div>
                        <form action="<?php echo e(route('ukm.cair',['id' => $ukms->id])); ?>" method="POST"
                         enctype="multipart/form-data">
                        	<?php echo csrf_field(); ?>
                            <div class="modal-body">
                            	<label>Jumlah tambahan donasi</label><br>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti-map-alt"></span></div>
                                        <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Masukkan tambahan donasi" name="tambah_donasi" required>
                                    </div>
                                    <br>
                                    <label>Jumlah tambahan tahun</label><br>
                                    <div class="input-group">
                                        <div class="input-group-addon"><span class="ti-map-alt"></span></div>
                                        <input type="number" class="form-control" id="exampleInputEmail1" placeholder="Masukkan jumlah tahun" name="lama" required>
                                    </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default submit-mod" data-dismiss="modal">Batal</button>
                                <input type="hidden" name="_method" value="PUT">
                                <input type="submit" class="btn btn-default submit-mod-tambah" value="Tambah">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
							</tfoot>
						</table>
					</div>
				</div>

			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>