<?php $__env->startSection('content'); ?>
    <section>
        <div class="row pembayaran">
            <div class="container">
                <div class="col-md-5 col-md-offset-4">
                    <div class="panel panel-default" style="padding:30px;">
                        <div class="panel-body">
                            <?php if(session('status')): ?>
                            <div class="alert alert-success"><?php echo e(session('status')); ?> </div>
                            <?php elseif(session('gagal')): ?>
                            <div class="alert alert-danger"><?php echo e(session('gagal')); ?> </div>
                            <?php endif; ?>
                            <p class="text-center text">Upload bukti transfer</p>
                            <div class="form-group">
                                <form action="<?php echo e(route('proses.donasi')); ?>" method="POST" enctype="multipart/form-data" accept="image/*">
                                    <?php echo csrf_field(); ?>
                                <input type="tel" class="form-control" id="exampleInputEmail1" placeholder="Masukkan kode unik anda" name="id" onkeypress="return isNumberKey(event)" required>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile">Upload Bukti Transfer</label>
                                <input type="file" id="exampleInputFile" name="photo" accept="image/*" required>
                                <p class="help-block" >Bukti transfer</p>
                            </div>
                            <!-- <input type="hidden" name="_method" value="PUT" > -->
                                <button type="submit" class="btn btn-default upload" style="margin-left: 60px;">Upload</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.viewpublic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>