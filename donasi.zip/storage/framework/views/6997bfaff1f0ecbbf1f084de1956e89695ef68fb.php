<?php $__env->startSection('title'); ?>Edit Beasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			
			<div class="box-body"><h2>Edit Beasiswa</h2>
		<form
		action="<?php echo e(route('manage-beasiswa.update', ['id' => $beasiswa->id])); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<input
	type="hidden"
	value="PUT"
	name="_method">
		<label for="title">Nama penerima</label> <br>
		<input type="text" class="form-control" name="nama_penerima"
		value="<?php echo e($beasiswa->nama_penerima); ?>" required>
		<br>

		<label for="cover">Dokumentasi</label><br>
		<small class="text-muted">Current photo</small><br>
		<?php if($beasiswa->dokumentasi): ?>
		<img src="<?php echo e(asset('storage/' . $beasiswa->dokumentasi)); ?>" width="120px"/>
		<?php endif; ?>
		<br><br>
		<input
		type="file" class="form-control"
		name="dokumentasi"
		>
		<small class="text-muted">Kosongkan jika tidak ingin mengubah cover</small>
		<br><br>
		<label for="description">Deskripsi <?php echo e($beasiswa->pendidikan); ?></label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Masukkan deskripsi" rows="5" required><?php echo e($beasiswa->deskripsi); ?></textarea>
		<br>
		<br>
		<label for="title">Asal Mitra</label> <br>
		<select class="form-control" name="mitra">
			<?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($mitras->id); ?>" <?php echo e($beasiswa['id_mitra'] == $mitras['id'] ? 'selected' : ''); ?>><?php echo e($mitras->nama); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<br>
	<button
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >Publish</button>
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>