<?php $__env->startSection('content'); ?>
    <section>
        <div class="input">
            <div class="container main-header">
                <h2 class="text-center">Daftar penerima beasiswa</h2>
                <h4 class="text-center">Untuk anak yatim yang berprestasi</h4><hr style="background-color:#e2dede; height:1px;">
                <div>
                    <?php $__currentLoopData = $beasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beasiswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(route('beasiswa.show', ['id' => $beasiswas->id])); ?>" class="thumbnail thumb">
                            <img src="<?php echo e(asset('storage/'. $beasiswas->dokumentasi)); ?>" alt="...">
                            <div class="caption">
                                <h3><?php echo e($beasiswas->nama_penerima); ?></h3>
                                <p>Diterima per semsester <strong>Rp. <?php echo e(format_uang($beasiswas->jumlah_persemester)); ?></strong></p>
                                <p>Telah Terima <strong>Rp. <?php echo e(format_uang($beasiswas->jumlah_total)); ?></strong></p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.donatur', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>