
<?php $__env->startSection('title'); ?> Detail Admin <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-8">

<div class="box">
	<h2 align="center">Detail admin</h2>
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Name </b></label><br>
			<?php echo e($admin->name); ?>

			<br><br>
			<label><b>Email</b></label><br>
			<?php echo e($admin->email); ?>

			<br><br>
			<label><b>Phone </b></label><br>
			<?php echo e($admin->phone); ?>

			<br><br>
			<label><b>Photo </b></label><br>
			<img src="<?php echo e(asset('storage/' . $admin->foto)); ?>"
			width="160px">
		</div>
	</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>