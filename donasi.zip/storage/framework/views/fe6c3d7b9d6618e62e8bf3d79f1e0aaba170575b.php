

<?php $__env->startSection('title'); ?>Tambah Mitra
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<div class="box-body">

<h2 align="center">Tambahkan mitra</h2>
		<form
		action="<?php echo e(route('manage-mitra.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama mitra</label> <br>
		<input type="text" class="form-control" name="nama"
		placeholder="Masukkan nama mitra" value="<?php echo e(old('nama')); ?>" required>
		<label for="description">Alamat</label><br>
		<textarea name="alamat" id="description" class="form-control"
		placeholder="Masukkan alamat mitra" rows="3" required><?php echo e(old('alamat')); ?></textarea>
		<br>
		<label for="title">Email</label> <br>
		<input type="email" class="form-control" name="email"
		placeholder="Masukkan email" value="<?php echo e(old('email')); ?>"required>
		<br>
		<label for="title">Jumlah angggota</label> <br>
		<input type="text" class="form-control" name="jumlah"
		placeholder="Masukkan jumlah anggota" required>
		<br>
	<button
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >Publish</button>
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>