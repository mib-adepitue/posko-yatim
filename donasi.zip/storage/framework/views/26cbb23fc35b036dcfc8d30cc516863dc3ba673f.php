<?php $__env->startSection('title'); ?>Add yatim
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<div class="box-body">

<h2 align="center">Tambahkan anak yatim</h2>
		<form
		action="<?php echo e(route('manage-yatim.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama anak</label> <br>
		<input type="text" class="form-control" name="nama"
		placeholder="Masukkan nama yatim" required>
		<br>
		<label for="title">Cita-cita</label> <br>
		<input type="text" class="form-control" name="cita"
		placeholder="Masukkan cita-cita" required>
		<br>
		<label for="title">Tempat lahir</label> <br>
		<input type="text" class="form-control" name="tempat"
		placeholder="Tempat lahir" required>
		<br>
		<label for="title">Tanggal lahir</label> <br>
		<input type="date" class="form-control" name="ttl"
		placeholder="Tempat lahir" required>	
		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Give a description about this book" rows="5" required></textarea>
		<br>
		<label for="title">Jenis Kelamin</label> <br>
		<select class="form-control" name="jkel">
			<option value="L" >Laki-laki</option>
			<option value="P" >Perempuan</option>
		</select>
		<br>
	<button
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >Publish</button>
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>