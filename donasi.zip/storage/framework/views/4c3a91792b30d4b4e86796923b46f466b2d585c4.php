<?php $__env->startSection('title'); ?>Donasi Create Pemberdayaan
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php endif; ?>
		<form
		action="<?php echo e(route('pemberdayaan.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama Penerima</label> <br>
		<input type="text" class="form-control" name="title"
		placeholder="Book title">
		<br>
		<label for="cover">Dokumentasi</label>
		<input type="file" class="form-control" name="cover">
		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="description" id="description" class="form-control"
		placeholder="Give a description about this book"></textarea>
		<br>
	<label for="stock">Jumlah</label><br>
	<input type="number" class="form-control" id="stock" name="stock"
	min=0 value=0>
	<button
	class="btn btn-primary"
	name="save_action"
	value="PUBLISH">Publish</button>
	<button
	class="btn btn-secondary"
	name="save_action"
	value="DRAFT">Save as draft</button>
</form>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>