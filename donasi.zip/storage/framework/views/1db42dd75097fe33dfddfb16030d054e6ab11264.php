<?php $__env->startSection('title'); ?>Posko yatim - ukm <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="input">
            <div class="container main-header">
                <h2 class="text-center">Informasi Penerima Dana UKM</h2>
                <h4 class="text-center">Bagi kaum dhuafa untuk modal membuka usaha kecil</h4><hr style="background-color:#e2dede; height:1px;">
                <div class="col-md-6 col-md-offset-3">
                      <form action="<?php echo e(route('usaha-kecil-menengah.index')); ?>" >
                            <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="text" class="form-control" name="cari" value="<?php echo e(Request::get('cari')); ?>" placeholder="Cari nama penerima...">
                        <span class="input-group-btn">
                            <input class="btn btn-default" type="submit" value="Go">
                        </span>
                        </form>
                    </div>
                </div>
            </div>
                <div class="container main-header">
                    <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(route('usaha-kecil-menengah.show', ['id' => $ukms->id])); ?>" class="thumbnail thumb">
                            <img src="<?php echo e(asset('storage/'. $ukms->dokumentasi)); ?>" alt="...">
                            <div class="caption">
                                <h3><?php echo e($ukms->nama_penerima); ?></h3>
                                <p>Telah terima <strong>Rp. <?php echo e(format_uang($ukms->jumlah_total)); ?></strong></p>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donatur', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>