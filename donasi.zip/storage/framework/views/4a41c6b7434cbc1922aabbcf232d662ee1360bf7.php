
<?php $__env->startSection('title'); ?>Posko yatim - donasi sekarang <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="row input">
            <div class="container">
                <div class="col-md-5 col-md-offset-1"><img src="<?php echo e(asset('zakat/img/payment-method.png')); ?>" alt="working" class="img-responsive"></div>
                <div class="col-md-4 col-md-offset-1">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <?php if(session('status')): ?>
                            <div class="alert alert-success"><?php echo e(session('status')); ?> </div>
                            <?php elseif(session('gagal')): ?>
                            <div class="alert alert-danger"><?php echo e(session('gagal')); ?> </div>
                            <?php endif; ?>
                            <p class="text-center text">Mulai Berdonasi</p>
                            <form action="<?php echo e(route('donasi-sekarang.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                        <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama Lengkap Anda" name="nama" value="<?php echo e(old('nama')); ?>" required>
                                    </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Kontak" name="nohp" value="<?php echo e(old('nohp')); ?>" onkeypress="return isNumberKey(event)" required>
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Pekerjaan Anda" name="pekerjaan" value="<?php echo e(old('pekerjaan')); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="sr-only" for="exampleInputAmount">Amount (in dollars)</label>
                                    <div class="input-group">
                                        <div class="input-group-addon">Rp</div>
                                        <input type="text" class="form-control" name="jumlah" id="uang" placeholder="0"  onkeypress="return isNumberKey(event)" value="<?php echo e(old('jumlah')); ?>" required>
                                    </div>
                                    <!-- <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Nominal Donasi"  min=10000 required> -->
                                </div>
                                <input type="submit" class="btn btn-default submit"value="Lanjut Pembayaran">
                            </form>
                            <p class="text-center">Sudah melakukan donasi? <span><a href="<?php echo e(route('bayar.donasi')); ?>">klik disini</a></span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.viewpublic', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>