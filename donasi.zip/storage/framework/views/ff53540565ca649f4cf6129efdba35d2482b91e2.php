<?php $__env->startSection('title'); ?>Posko yatim - daftar mitra <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section>
        <div class="dashboard">
            <div class="container">
                <div class="col-md-3">
                    <a href="#" class="thumbnail">
                        <img src="<?php echo e(asset('storage/'. Auth::user()->foto)); ?>" alt="background-user">
                    </a>
                    <div class="list-group">
                        <a href="<?php echo e(route('donatur.dashboard')); ?>" class="list-group-item"> Overview</a>
                        <a href="<?php echo e(route('donasi.donatur')); ?>" class="list-group-item">Donasi Sekarang</a>
                        <a href="<?php echo e(route('edit.profile')); ?>" class="list-group-item">Edit Profil</a>
                        <a href="<?php echo e(route('daftar.donatur')); ?>" class="list-group-item">Lihat daftar donatur</a>
                        <a href="<?php echo e(route('daftar.mitra')); ?>" class="list-group-item active">Lihat daftar mitra Posko Yatim</a>
                        <a href="<?php echo e(route('logout')); ?>" class="list-group-item" 
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                        <a data-toggle="modal" data-target="#confirm-absen" class="list-group-item" style="cursor:pointer;">Berhenti jadi donatur</a>
                    </div>
                </div>
                <div class="col-md-9">
                    <h2 style="margin-top:40px;">Daftar Mitra Posko Yatim</h2><hr style="background-color:#01579b; height:3px; border-radius:5px;">
                    <table id="example" class="display nowrap">
                        <thead style="background-color: #01579b; color:#ffffff;">
                            <tr>			
                                <th>Nama</th>
                                <th>Alamat</th>
                                <th>Email</th>
                                <th>Jumlah Anak Yatim</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>				
                                <td><?php echo e($mitras->nama); ?></td>
                                <td><?php echo e($mitras->alamat); ?></td>
                                <td><?php echo e($mitras->email); ?></td>
                                <td><?php echo e($mitras->jumlah); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="modal fade" id="confirm-absen" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Berhenti jadi Donatur</h4>
                            </div>
                            <div class="modal-body">
                                <p>Apakah Anda yakin ingin melanjutkan ?</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal" style="margin-top:24px; 
                                background-color: #fb0000; border-color: #fb0000;">Batal</button>
                                <form action="<?php echo e(route('stop-donatur')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                <input type="submit" name="" class="btn btn-primary btn-ok" value="Konfirmasi">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.donatur', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>