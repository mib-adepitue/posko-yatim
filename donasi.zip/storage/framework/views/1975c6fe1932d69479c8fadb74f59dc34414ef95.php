<?php $__env->startSection('title'); ?> List Beasiswa <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
			<?php endif; ?>
			<h2>List Beasiswa __ Saldo Rp. <?php echo e($total); ?></h2>

				<div class="row">
					<div class="col-md-12 text-right">
						<a
						href="<?php echo e(route('manage-beasiswa.create')); ?>"
						class="btn btn-primary fa fa-plus btn-flat"
						> Tambah Beasiswa</a>
					</div>
				</div>
				<?php
				$no = 1;
				?>
				<div class="box">
					<!-- /.box-header -->
					<div class="box-body">
						<table class="table table-bordered table-stripped" id="example1" style="width: 100%">
							<thead>
								<tr>
									<th>No.</th>
									<th>Nama penerima</th>
									<th>Asal mitra</th>
									<th>Jenjang pendidikan</th>
									<th>Jumlah persemester</th>
									<th>Telah terima</th>
									<th>Lama donasi</th>
									<th>Status</th>
									<th>Cairkan beasiswa</th>
									<th>Terakhir diberikan</th>
									<th>Action</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $beasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beasiswas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($no++); ?></td>
									<td><?php echo e($beasiswas->nama_penerima); ?></td>
									<td><?php echo e($beasiswas->namamitra); ?></td>
									<td><?php echo e($beasiswas->pendidikan); ?></td>
									<td>Rp. <?php echo e(format_uang($beasiswas->jumlah_persemester)); ?></td>
									<td>Rp. <?php echo e(format_uang($beasiswas->jumlah_total)); ?></td>
									<td><?php echo e($beasiswas->lama); ?> semester</td>
									<td> <?php if($beasiswas->status == 'active'): ?><span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Active</i></span>
									 <?php else: ?><span class="label label-warning" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Inactive</i></span> 
									  <?php endif; ?> </td>
									  <td>
									  	<?php if($beasiswas->status == 'active'): ?>
									<form
									method="POST"
							action="<?php echo e(route('manage-beasiswa.cair', ['id' => $beasiswas->id])); ?>"
									class="d-inline"
									onsubmit="return confirm('Cairkan Beasiswa ?')">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="_method" value="PUT">
									<input type="submit" value="Cairkan" class="btn btn-primary">
										</form>
									
									  	<?php else: ?> 
									  	<form
									method="POST"
							action="<?php echo e(route('manage-beasiswa.cair', ['id' => $beasiswas->id])); ?>"
									class="d-inline"
									onsubmit="return confirm('Cairkan Beasiswa ?')">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="_method" value="PUT">
									<input type="submit" value="Cairkan" class="btn btn-primary" disabled="">
										</form>
									  	<?php endif; ?>
									  </td>
									  <td><?php echo e($beasiswas->updated_at); ?></td>
									<td>
										<div class="row1">
											<a href="<?php echo e(route('manage-beasiswa.edit', ['id' => $beasiswas->id])); ?>" class="fa fa-edit"> Edit </a>
											<a href="<?php echo e(route('manage-beasiswa.show', ['id' => $beasiswas->id])); ?>" class="fa fa-eye"> View </a>
											<form
											method="POST"
											action="<?php echo e(route('manage-beasiswa.destroy', ['id' => $beasiswas->id])); ?>"
											class="d-inline"
											onsubmit="return confirm('Hapus Beasiswa	?')"
											>
											<?php echo csrf_field(); ?>
											<input type="hidden" name="_method" value="DELETE">
											<input type="submit" value="Delete" class="btn btn-danger">
										</form>
										</div>
									</td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
							<tfoot>
							</tfoot>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>