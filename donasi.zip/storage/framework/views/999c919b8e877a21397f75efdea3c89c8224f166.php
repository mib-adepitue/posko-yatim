
<?php $__env->startSection('title'); ?> Detail ukm <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Nama Penerima</b></label><br>
			<?php echo e($show->nama_penerima); ?>

			<br><br>
			<label><b>Nama Usaha</b></label><br>
			<?php echo e($show->nama_usaha); ?>

			<br><br>
			<label><b>Jumlah awal</b></label><br>
			Rp. <?php echo e(format_uang($show->jumlah_awal)); ?>

			<br><br>
			<label><b>Telah terima</b></label><br>
			Rp. <?php echo e(format_uang($show->jumlah_total)); ?>

			<br><br>
			<label><b>Deskripsi </b></label><br>
			<?php echo e($show->deskripsi); ?>

			<br><br>
			<label><b>Status </b></label><br>
			<?php if($show->status == 'active'): ?> <span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Active</i></span>
									 <?php else: ?><span class="label label-warnign" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Inactive</i></span> 
									  <?php endif; ?>
			<br><br>
			<label><b>Dokumentasi </b></label><br>
			<?php if($show->dokumentasi): ?>
			<img src="<?php echo e(asset('storage/' . $show->dokumentasi)); ?>"
			width="120px">
			<?php endif; ?>
			<br><br>
			<label><b>Penulis </b></label><br>
			<?php echo e($show->namaadmin); ?>

			<br><br>
			<label><b>Ditulis Pada : </b></label><br>
			<?php echo e($show->created_at); ?>

			<br><br>

		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>