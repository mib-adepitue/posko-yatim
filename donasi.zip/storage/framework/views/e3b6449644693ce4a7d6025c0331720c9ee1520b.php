<?php $__env->startSection('title'); ?>Tambah kegiatan infak
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> Foto minimal 2MB<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
		<div class="box">
			<div class="box-body">

<h2 align="center">Tambah Kegiatan Infak</h2>
<h4 align="center">Saldo Rp. <?php echo e($total); ?></h4>
		<form
		action="<?php echo e(route('manage-infak.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama kegiatan</label> <br>
		<input type="text" class="form-control" name="nama_kegiatan"
		placeholder="Masukkan nama kegiatan" value="<?php echo e(old('nama_kegiatan')); ?>" required>
		<br>
		<label for="cover">Dokumentasi</label>
		<input type="file" class="form-control" name="dokumentasi" value="<?php echo e(old('dokumentasi')); ?>" accept="image/*" required>
		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Deskripsi kegiatan ini" rows="5" required><?php echo e(old('deskripsi')); ?></textarea>
		<br>
	<label for="stock">Jumlah dana : Rp. <?php echo e($total); ?></label><br>
	<input type="number" class="form-control" id="stock" name="jumlah"
	min=0 value="<?php echo e(old('jumlah')); ?>" accept="image/*" required>
	<br>
	<button
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >Publish</button>
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>