<?php $__env->startSection('title'); ?> List donatur <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
	<div class="row">
		<div class="col-md-12">
			<?php if(session('status')): ?>
			<div class="alert alert-success">
				<?php echo e(session('status')); ?>

			</div>
			<?php elseif(session('gagal')): ?>
			<div class="alert alert-danger">
				<?php echo e(session('gagal')); ?>

			</div>
			<?php endif; ?>
		</div>

			<h2>List Donatur</h2>
		<?php
		$no = 1;
		?>
		<div class="col-md-6">
	<ul class="nav nav-pills">
		<li class="nav-item">
			<a class="btn-primary <?php echo e(Request::get('status') == NULL &&
			Request::path() == 'admin/manageuser' ? 'active' : ''); ?>" href="
			<?php echo e(route('manageuser.index')); ?>">Donatur aktif</a>
		</li>
		<li class="nav-item">
			<a class="btn-primary <?php echo e(Request::get('status') == 'donatur-tidak-aktif' ?
			'active' : ''); ?>" href="<?php echo e(route('manageuser.index', ['status' =>
			'donatur-tidak-aktif'])); ?>">Donatur tidak aktif</a>
		</li>
	</ul>
</div>
<br>
<br>
<?php if(Request::get('status') == NULL && Request::path() == 'admin/manageuser'): ?>
<div class="box">
			<!-- /.box-header -->
			<div class="box-body">
				<table class="table table-stripped table-bordered" id="example1" style="width: 100%">
					<thead>
						<tr>
							<th><b>No.</b></th>
							<th><b>Nama</b></th>
							<th><b>Status</b></th>
							<th><b>Email</b></th>
							<th><b>Donasi wajib</b></th>
							<th><b>Total donasi</b></th>
							<th><b>Action</b></th>

						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($users->name); ?></td>
							<td><?php if($users->status == 'active'): ?>
								<span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Donatur aktif </i></span>
							<?php else: ?>
							<span class="label label-danger" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Tidak aktif </i></span>
						<?php endif; ?></td>
						<td><a href="mailto:<?php echo e($users->email); ?>"><?php echo e($users->email); ?></a></td>
							
							<td>Rp. <?php echo e(format_uang($users->donasi_awal)); ?></td>
							<td>Rp. <?php echo e(format_uang($users->totaldonasi)); ?></td>
							<td>
							<a href="<?php echo e(route('manageuser.show',['id'=>$users->id])); ?>" class="fa fa-eye" >view </a>
							<?php if($users->status == 'active'): ?>
							<form action="<?php echo e(route('manageuser.update',['id' => $users->id])); ?>" method="POST">
								<?php echo csrf_field(); ?>
								<input type="hidden" name="_method" value="PUT">
								<input type="submit" class="btn btn-danger" name="" onclick="return confirm('Hentikan donatur ?');" value="Hentikan Donatur">
							</form>
							<?php else: ?>
							<form action="" method="">
								<input type="submit" class="btn btn-danger" name="" value="Hentikan Donatur" disabled="">
							</form>
							<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr></tr>
			</tfoot>
		</table>
	</div>
</div>
<?php elseif(Request::get('status') == 'donatur-tidak-aktif'): ?>
<div class="box">
			<!-- /.box-header -->
			<div class="box-body">
				<table class="table table-stripped table-bordered" id="example1" style="width: 100%">
					<thead>
						<tr>
							<th><b>No.</b></th>
							<th><b>Nama</b></th>
							<th><b>Status</b></th>
							<th><b>Email</b></th>
							<td><b>Deleted by</b></td>
							<th><b>Action</b></th>

						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($no++); ?></td>
							<td><?php echo e($users->name); ?></td>
							<td><?php if($users->status == 'active'): ?>
								<span class="label label-success" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Donatur aktif </i></span>
							<?php else: ?>
							<span class="label label-warning" style="font-size: 13px;"><i class="fa fa-check-circle-o"> Tidak aktif </i></span>
						<?php endif; ?></td>
						<td><a href="mailto:<?php echo e($users->email); ?>"><?php echo e($users->email); ?></a></td>
						<td>admin <strong><?php echo e($users->namaadmin); ?></strong></td>
							<td>
							<a href="<?php echo e(route('manageuser.show',['id'=>$users->id])); ?>" class="fa fa-eye" >view </a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
			<tfoot>
				<tr></tr>
			</tfoot>
		</table>
	</div>
</div>
<?php endif; ?>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>