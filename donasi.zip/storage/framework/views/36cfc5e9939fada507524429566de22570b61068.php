<?php $__env->startSection('title'); ?>Edit Mitra
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<h2>Edit mitra</h2>
		<div class="box">
			<div class="box-body">
		<form
		action="<?php echo e(route('manage-mitra.update', ['id' => $mitra->id ])); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
	<input
	type="hidden"
	value="PUT"
	name="_method">
		<label for="title">Nama mitra</label> <br>
		<input type="text" class="form-control" name="nama"
		placeholder="Masukkan nama" value="<?php echo e($mitra->nama); ?>" required>
		<br>
<!-- <?php echo e(old('jkel') == "L" ? 'selected' : ''); ?> -->
		
		<label for="description">Alamat</label><br>
		<textarea name="alamat" id="description" class="form-control" required><?php echo e($mitra->alamat); ?></textarea>
		<br>
		<label for="stock">email</label><br>
	<input type="email" class="form-control" id="stock" name="email"
	 value="<?php echo e($mitra->email); ?>" required><br>
	<label for="stock">Jumlah anggota</label><br>
	<input type="text" class="form-control" id="stock" name="jumlah"
	 value="<?php echo e($mitra->jumlah); ?>" required>
	<br>
	<input type="submit" class="btn btn-primary" value="Publish">
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>