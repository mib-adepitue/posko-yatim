<?php $__env->startSection('title'); ?>Detail yatim <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="box">
	<div class="box-body">

	<div class="card">
		<div class="card-body">
			<label><b>Nama </b></label><br>
			<?php echo e($yatim->name); ?>

			<br><br>
			<label><b>Cita-cita</b></label><br>
			<?php echo e($yatim->cita); ?>

			<br><br>
			<label><b>Jenis Kelamin </b></label><br>
			<?php if($yatim->jkel == 'L'): ?> Laki-laki
			<?php else: ?> Perempuan
			<?php endif; ?>
			<br><br>
			<label><b>Tempat, Tanggal lahir </b></label><br>
			<?php echo e($yatim->tgl_lahir); ?>

			<br><br>
			<label><b>Deskripsi </b></label><br>
			<?php echo e($yatim->deskripsi); ?>

			<br><br>
			<label><b>ditambahkan oleh</b></label><br>
			admin <strong><?php echo e($yatim->namaadmin); ?></strong>


		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>