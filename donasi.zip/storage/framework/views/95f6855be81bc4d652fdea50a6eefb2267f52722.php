<?php $__env->startSection('title'); ?>Tambah Ukm
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container col-sm-12">
<div class="row">
	<div class="col-md-8">
		<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php elseif(session('gagal')): ?>
		<div class="alert alert-danger">
			<?php echo e(session('gagal')); ?>

		</div>
		<?php endif; ?>
		<div class="box">
			<div class="box-body">

<h2 align="center">Tambah Beasiswa</h2>
<h4 align="center">Saldo Rp.<?php echo e($total); ?></h4>
		<form
		action="<?php echo e(route('manage-beasiswa.store')); ?>"
		method="POST"
		enctype="multipart/form-data"
		class="shadow-sm p-3 bg-white"
		>
		<?php echo csrf_field(); ?>
		<label for="title">Nama penerima</label> <br>
		<input type="text" class="form-control" name="nama_penerima"
		placeholder="Masukkan nama " value="<?php echo e(old('nama_penerima')); ?>" required>
		<br>
		<label for="cover">Dokumentasi</label>
		<input type="file" class="form-control" name="dokumentasi" value="<?php echo e(old('dokumentasi')); ?>" accept="image/*" required>
		<br>
		<label for="description">Deskripsi</label><br>
		<textarea name="deskripsi" id="description" class="form-control"
		placeholder="Masukkan deskripsi" rows="5" required><?php echo e(old('deskripsi')); ?></textarea>
		<br>
		<label for="title">Jenjang pendidikan</label> <br>
		<select class="form-control" name="pendidikan">
			<option value="S1">S1</option>
			<option value="D3" >D3</option>
		</select>
		<br>
		<label for="title">Asal Mitra</label> <br>
		<select class="form-control" name="mitra">
			<?php $__currentLoopData = $mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mitras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<option value="<?php echo e($mitras->id); ?>"><?php echo e($mitras->nama); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>
		<br>
	<label for="stock">Jumlah beasiswa persemester  </label><br>
	<input type="number" class="form-control" id="stock" name="jumlah_persemester"
	min=0 required>
	<br>
	<button
	class="btn btn-primary btn-flat"
	name="save_action"
	value="PUBLISH" >Publish</button>
</form>
</div>
</div>
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>