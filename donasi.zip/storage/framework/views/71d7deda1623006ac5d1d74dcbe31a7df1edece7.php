<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/bootstrap/dist/css/bootstrap.min.css')); ?>">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/Ionicons/css/ionicons.min.css')); ?>">
  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo e(asset('bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/AdminLTE.min.css')); ?>">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/skins/_all-skins.min.css')); ?>">


  <!-- Google Font -->
  <link rel="stylesheet"
        href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic')); ?>">
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="#" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Ps</b>Ytm</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Posko</b>Yatim</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      <?php
       $foto = Auth::user()->foto;
      ?>
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo e(asset('storage/' . $foto)); ?>" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?php echo e(asset('storage/' . $foto)); ?>" class="img-circle" alt="User Image">
                <p>
                <!--user--><?php echo e(Auth::user()->name); ?><br>
              <!-- <button class="btn btn-default"> -->
                  <a class="btn btn-default" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                  <!-- </button> -->
                </p>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
         
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('storage/' . $foto)); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p> <?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="Header <?php echo e(Request::path() == 'admin' ? 'active' : ''); ?>">
          <a href="/admin">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
       
         <li class="treeview <?php echo e(Request::path() == 'admin/manage-donasi-donatur' ? 'active' : '' || Request::path() == 'admin/manage-donasi-user' ? 'active' : ''); ?>">
          <a href="#">
            <i class="fa fa-dollar"></i> <span>Terima Donasi</span>
            <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::path() == 'admin/manage-donasi-user' ? 'active' : ''); ?>"><a href="<?php echo e(route('manage-donasi-user.index')); ?>"><i class="fa fa-circle-o"></i>Donasi user</a></li>
            <li class="<?php echo e(Request::path() == 'admin/manage-donasi-donatur' ? 'active' : ''); ?>"><a href="<?php echo e(route('manage-donasi-donatur.index')); ?>"><i class="fa fa-circle-o"></i>Donasi donatur</a></li>
          </ul>
        </li><!-- 
        <li class="treeview">
          <a href="#">
            <i class="fa fa-sitemap"></i> <span>Manage Penyaluran</span>
            <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('penyaluran.create')); ?>"><i class="fa fa-circle-o"></i>Mulai Donasi</a></li>
            <li><a href="<?php echo e(route('penyaluran.index')); ?>"><i class="fa fa-circle-o"></i>Penyaluran</a></li>
          </ul>
        </li> -->
        <li class="treeview ">
          <li class="<?php echo e(Request::path() == 'admin/manage-infak' ? 'active' : ''); ?>"><a href="<?php echo e(route('manage-infak.index')); ?>">
            <i class="fa fa-google-wallet"></i> <span>Manage Kegiatan Infak</span>
          </a></li>
        </li>
        <li class="treeview">
          <li class="<?php echo e(Request::path() == 'admin/manage-beasiswa' ? 'active' : ''); ?>"><a href="<?php echo e(route('manage-beasiswa.index')); ?>">
            <i class="fa fa-graduation-cap"></i> <span>Manage Beasiswa</span>
          </a></li>
        </li>
        <li class="treeview">
          <li class="<?php echo e(Request::path() == 'admin/ukm' ? 'active' : ''); ?>"><a href="<?php echo e(route('ukm.index')); ?>">
            <i class="fa fa-user-md"></i> <span>Manage UKM</span>
          </a></li>
        </li>
        <li class="treeview">
          <li class="<?php echo e(Request::path() == 'admin/manage-mitra' ? 'active' : ''); ?>"><a href="<?php echo e(route('manage-mitra.index')); ?>">
            <i class="fa fa-table"></i> <span>Manage Mitra</span>
          </a></li>
        </li>
         <li class="treeview <?php echo e(Request::path() == 'admin/manageuser'  ? 'active' : ''); ?>">
          <a href="#">
            <i class="fa fa-user"></i> <span>Manage Users</span>
            <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::path() == 'admin/manageuser' ? 'active' : ''); ?>"><a href="<?php echo e(route('manageuser.index')); ?>"><i class="fa fa-circle-o"></i>All Users</a></li>
          </ul>
        </li>
        <li class="treeview <?php echo e(Request::path() == 'admin/manageadmin' ? 'active' : '' || Request::path() == 'admin/manageadmin/create' ? 'active' : ''); ?> ">
          <a href="#">
            <i class="fa fa-users"></i> <span>Manage Admin</span>
            <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
          </a>
          <ul class="treeview-menu">
            <li class="<?php echo e(Request::path() == 'admin/manageadmin' ? 'active' : ''); ?>"><a href="<?php echo e(route('manageadmin.index')); ?>"><i class="fa fa-circle-o"></i>All admin</a></li>
            <li class="<?php echo e(Request::path() == 'admin/manageadmin/create' ? 'active' : ''); ?>"><a href="<?php echo e(route('manageadmin.create')); ?>"><i class="fa fa-circle-o"></i>Add admin</a></li>
          </ul>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <?php echo $__env->yieldContent('content-header'); ?>
    </section>

    <!-- Main content -->
    <section class="content">
    <?php echo $__env->yieldContent('content'); ?>
  </section>
    <!-- /.content -->
</div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <strong>Copyright &copy; </strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
 
  <!-- /.control-sidebar -->
  <!-- Add the sidebars background. This div must be placed
       immediately after the control sidebar -->

</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="<?php echo e(url('bower_components/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- DataTables -->
<script src="<?php echo e(url('bower_components/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(url('bower_components/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
<!-- SlimScroll -->
<script src="<?php echo e(url('bower_components/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<!-- FastClick -->
<script src="<?php echo e(url('bower_components/fastclick/lib/fastclick.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(url('dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(url('dist/js/demo.js')); ?>"></script>
<!-- page script -->
<script>
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;

            return true;
        }

        function isDecimalKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 46 || charCode > 57))
                return false;

            return true;
        }

        function isUpperKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode
            if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode < 65 || charCode > 90))
                return false;

            return true;
        }

  $(function() {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': true,
      'searching'   : true,
      'ordering'    : true,
      'info'        : true,
      'scrollX'     : true
    })
    $('#example2').DataTable({
      'paging'      : false,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : false,
      'autoWidth'   : true
    })
  })
</script>
</body>
</html>
