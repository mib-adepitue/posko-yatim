<?php $__env->startSection('title'); ?> Dashboard <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo e($totaldonatur); ?> orang</h3>

              <p>Jumlah Donatur tetap</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="<?php echo e(route('manageuser.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
         <div class="col-lg-3 col-xs-6" >
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo e($user); ?> orang</h3>

              <p>Donatur tidak tetap</p>
            </div>
            <div class="icon">
              <i class="ion ion-person"></i>
            </div>
            <a href="<?php echo e(route('manage-donasi-user.index')); ?>" class="small-box-footer" >More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <div class="col-lg-3 col-xs-6" >
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3>Rp. <?php echo e($totaldonasi); ?></h3>

              <p>Saldo</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="/admin" class="small-box-footer" onclick="penghasilan('<?php echo e($totaldonasi); ?>')">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
       
      </div>
    </section>
    <script type="text/javascript">
      function penghasilan(total){
        alert("Penghasilan Rp." + total);
      }
    </script>
    <!-- /.content -->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>