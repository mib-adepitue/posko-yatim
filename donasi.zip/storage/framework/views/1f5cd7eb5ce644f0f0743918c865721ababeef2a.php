<?php $__env->startSection('title'); ?> Donasi <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
		<div class="alert alert-success">
			<?php echo e(session('status')); ?>

		</div>
		<?php endif; ?>
				<?php
				$no = 1;
				?>
				<h2>Donasi user</h2>
<div class="box">
	<div class="box-body">	
		<table id="example1" class="table table-bordered table-striped" style="width: 100%">
			<thead>
				<tr>
					<th>No.</th>
					<th>Nama Pengirim</th>
					<th>Email</th>
					<th>No.Hp</th>
					<th>Pekerjaan</th>
					<th>Jumlah</th>
					<th>Action</th>
				</tr>
			</thead>

			<tbody>
				
				<?php $__currentLoopData = $donasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donasis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($no++); ?></td>
					<td><?php echo e($donasis->nama); ?></td>
					<td><?php echo e($donasis->email); ?></td>
					<td><?php echo e($donasis->nohp); ?></td>
					<td><?php echo e($donasis->pekerjaan); ?></td>
					<td><?php echo e($donasis->jumlah); ?></td>
					<td><form action="<?php echo e(route('managedonasi.update', ['id' => $donasis->id])); ?>"
						method="POST">
						<?php echo csrf_field(); ?>
						<input
						type="hidden"
						value="PUT"
						name="_method">
						<input onclick="return confirm('Donasi <?php echo e($donasis->nama); ?> Telah Diterima ?')" 
					type="submit"
					value="Donasi telah sampai"
					class="btn btn-primary btn-flat">
					</form></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
			<tfoot>
				<tr>
				</tr>
			</tfoot>
		</table>
	</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>